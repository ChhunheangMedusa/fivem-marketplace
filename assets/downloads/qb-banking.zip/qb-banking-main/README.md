🏦  QBCore Advanced Banking System
The ultimate Banking system with a sleek tablet UI, real-time banking  stats, and seamless management! 

![image](https://raw.githubusercontent.com/QBCoreStore/qb-banking/refs/heads/main/Capture.png)

Free Release at 100 GitHub Stars! ⭐ Help us reach the goal, and we’ll drop it for everyone!

Star the repo now & stay tuned! 
