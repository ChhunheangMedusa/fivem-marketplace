import { GetSVG } from './GetSVG';

export const Hook = { GetSVG }
